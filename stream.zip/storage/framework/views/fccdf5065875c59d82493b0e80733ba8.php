

<div <?php echo e($attributes->class('flex-1 pointer-events-none')); ?> data-flux-sidebar-spacer></div><?php /**PATH /home/novistech/laravel/stream/vendor/livewire/flux/src/../stubs/resources/views/flux/sidebar/spacer.blade.php ENDPATH**/ ?>