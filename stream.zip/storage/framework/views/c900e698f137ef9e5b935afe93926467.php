

<template name="cursor">
    <line <?php echo e($attributes->merge([
        'class' => 'text-zinc-500 dark:text-zinc-300',
        'type' => 'vertical',
        'stroke' => 'currentColor',
        'stroke-width' => '1',
        'stroke-dasharray' => '4,4',
    ])); ?>></line>
</template>
<?php /**PATH /home/novistech/laravel/stream/vendor/livewire/flux-pro/src/../stubs/resources/views/flux/chart/cursor.blade.php ENDPATH**/ ?>