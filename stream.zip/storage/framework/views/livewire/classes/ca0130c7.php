<?php

use Livewire\Component;

return new class extends Component
{
    public string $fullName = '';

    public string $email = '';

    public string $phone = '';

    public string $referralCode = '';

    public string $activationCode = '';

    public string $password = '';

    public string $passwordConfirmation = '';

    public bool $agreeTerms = false;

    public bool $showInvalidCodeModal = false;

    public function register(): void
    {
        // Show invalid activation code modal
        $this->showInvalidCodeModal = true;
    }

    public function closeModal(): void
    {
        $this->showInvalidCodeModal = false;
    }

    protected function view($data = [])
    {
        return app('view')->file('/home/novistech/laravel/stream/storage/framework/views/livewire/views/ca0130c7.blade.php', $data);
    }
};