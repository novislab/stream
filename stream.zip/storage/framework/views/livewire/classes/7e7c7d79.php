<?php

use Livewire\Component;

return new class extends Component
{
    //

    protected function view($data = [])
    {
        return app('view')->file('/home/novistech/laravel/stream/storage/framework/views/livewire/views/7e7c7d79.blade.php', $data);
    }
};