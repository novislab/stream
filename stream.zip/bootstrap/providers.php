<?php

use App\Providers\AppServiceProvider;

return [
    AppServiceProvider::class,
];
