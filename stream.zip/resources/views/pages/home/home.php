<?php

use Livewire\Component;

new class extends Component
{
    //
};
